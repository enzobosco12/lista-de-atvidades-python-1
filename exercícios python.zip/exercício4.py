r = float(input("Informe o raio: "))
a = float(input("Informe altura: "))

volume = 3.1415 * (r ** 2) * a
print(f"Volume: {volume:.2f}")