enzo1=float(input('nota1:'))
enzo2=float(input('nota2:'))
enzo3=float(input('nota3:'))

media=float(enzo1+enzo2+enzo3)/3
print('a média é:', media)