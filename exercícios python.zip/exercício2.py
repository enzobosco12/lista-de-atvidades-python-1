a=4
b=3

quadrado1= a**2
quadrado2= b**2
hipo= quadrado1+quadrado2
raiz= hipo **0.5

print('o valor da hipotenusa é:', raiz)